import { clerkClient, getAuth } from "@clerk/express";
import { eq } from "drizzle-orm";
import type { RequestHandler } from "express";
import { db, userRolesTable } from "@workspace/db";

const networkRoles = new Set(["network_super_admin", "national_administrator"]);

export const requireSignedIn: RequestHandler = (req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in is required." });
    return;
  }
  next();
};

export const requireNetworkAdmin: RequestHandler = async (req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in is required." });
    return;
  }

  let [role] = await db
    .select()
    .from(userRolesTable)
    .where(eq(userRolesTable.clerkUserId, userId))
    .limit(1);

  // The configured owner email is the only bootstrap path. The grant is stored
  // once in the app database and is never recreated after a role is revoked.
  const initialAdminEmail = process.env.ESPMUN_INITIAL_ADMIN_EMAIL
    ?.trim()
    .toLowerCase();
  if (!role && initialAdminEmail) {
    const user = await clerkClient.users.getUser(userId);
    const ownsBootstrapEmail = user.emailAddresses.some(
      (address) => address.emailAddress.toLowerCase() === initialAdminEmail,
    );
    if (ownsBootstrapEmail) {
      await db
        .insert(userRolesTable)
        .values({ clerkUserId: userId, role: "network_super_admin" })
        .onConflictDoNothing();
      [role] = await db
        .select()
        .from(userRolesTable)
        .where(eq(userRolesTable.clerkUserId, userId))
        .limit(1);
    }
  }

  if (!role || !networkRoles.has(role.role)) {
    res.status(403).json({
      error: initialAdminEmail
        ? "This account does not have permission to manage the ESPMUN network."
        : "Administrator setup is required before using the control centre.",
    });
    return;
  }

  next();
};
