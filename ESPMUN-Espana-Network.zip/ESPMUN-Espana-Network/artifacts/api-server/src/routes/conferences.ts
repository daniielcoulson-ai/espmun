import { clerkClient, getAuth } from "@clerk/express";
import {
  and,
  asc,
  count,
  desc,
  eq,
  gte,
  inArray,
  ne,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  ArchiveConferenceParams,
  CreateConferenceBody,
  CreateConferenceResponse,
  CreateCommitteeBody,
  CreateCommitteeParams,
  CreateCommitteeResponse,
  GetConferenceParams,
  GetConferenceResponse,
  GetDashboardResponse,
  GetPublicConferenceParams,
  GetPublicConferenceResponse,
  ListApplicationsResponse,
  ListCommitteesParams,
  ListCommitteesResponse,
  ListConferencesResponse,
  ListPublicConferencesResponse,
  SetConferencePublishedBody,
  SetConferencePublishedParams,
  SetConferencePublishedResponse,
  UpdateConferenceBody,
  UpdateConferenceParams,
  UpdateConferenceResponse,
} from "@workspace/api-zod";
import {
  applicationsTable,
  auditLogsTable,
  committeesTable,
  conferencesTable,
  db,
  userRolesTable,
} from "@workspace/db";
import { requireNetworkAdmin, requireSignedIn } from "../middlewares/adminAuth";

const router: IRouter = Router();

const levels = [
  "Local",
  "Provincial",
  "Regional",
  "National",
  "International",
] as const;

async function audit(
  actorUserId: string,
  action: string,
  entityType: string,
  entityId: string,
) {
  await db.insert(auditLogsTable).values({
    actorUserId,
    action,
    entityType,
    entityId,
  });
}

function toDateValue(value: Date | string | null | undefined) {
  if (value == null) return value ?? null;
  return value instanceof Date ? value.toISOString().slice(0, 10) : value;
}

function slugify(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

router.get("/dashboard", requireNetworkAdmin, async (_req, res): Promise<void> => {
  const [activeCount] = await db
    .select({ value: count() })
    .from(conferencesTable)
    .where(ne(conferencesTable.status, "archived"));
  const [draftCount] = await db
    .select({ value: count() })
    .from(conferencesTable)
    .where(eq(conferencesTable.status, "draft"));
  const [publishedCount] = await db
    .select({ value: count() })
    .from(conferencesTable)
    .where(eq(conferencesTable.status, "published"));
  const [applicationCount] = await db
    .select({ value: count() })
    .from(applicationsTable);
  const conferences = await db
    .select()
    .from(conferencesTable)
    .where(ne(conferencesTable.status, "archived"));
  const byLevel = Object.fromEntries(
    levels.map((level) => [
      level,
      conferences.filter((conference) => conference.level === level).length,
    ]),
  ) as Record<(typeof levels)[number], number>;
  const today = new Date().toISOString().slice(0, 10);
  const upcoming = await db
    .select()
    .from(conferencesTable)
    .where(
      and(
        eq(conferencesTable.status, "published"),
        gte(conferencesTable.startDate, today),
      ),
    )
    .orderBy(asc(conferencesTable.startDate))
    .limit(5);

  res.json(
    GetDashboardResponse.parse({
      conferenceTotal: activeCount.value,
      draftTotal: draftCount.value,
      publishedTotal: publishedCount.value,
      applicationTotal: applicationCount.value,
      byLevel,
      upcoming,
    }),
  );
});

router.get("/conferences", requireNetworkAdmin, async (_req, res): Promise<void> => {
  const conferences = await db
    .select()
    .from(conferencesTable)
    .orderBy(desc(conferencesTable.updatedAt));
  res.json(ListConferencesResponse.parse(conferences));
});

router.post("/conferences", requireNetworkAdmin, async (req, res): Promise<void> => {
  const input = CreateConferenceBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }
  const data = input.data;
  const baseSlug = slugify(data.name) || "conference";
  const [existing] = await db
    .select({ id: conferencesTable.id })
    .from(conferencesTable)
    .where(eq(conferencesTable.slug, baseSlug))
    .limit(1);
  const slug = existing ? `${baseSlug}-${Date.now().toString(36)}` : baseSlug;
  const [created] = await db
    .insert(conferencesTable)
    .values({
      name: data.name.trim(),
      slug,
      level: data.level,
      city: data.city.trim(),
      region: data.region.trim(),
      venue: data.venue ?? null,
      startDate: toDateValue(data.startDate)!,
      endDate: toDateValue(data.endDate)!,
      applicationDeadline: toDateValue(data.applicationDeadline),
      theme: data.theme ?? null,
      description: data.description ?? null,
      fee: data.fee ?? null,
      status: "draft",
    })
    .returning();
  const actor = getAuth(req).userId!;
  await audit(actor, "conference.created", "conference", String(created.id));
  res.status(201).json(CreateConferenceResponse.parse(created));
});

router.get(
  "/conferences/:id",
  requireNetworkAdmin,
  async (req, res): Promise<void> => {
    const params = GetConferenceParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [conference] = await db
      .select()
      .from(conferencesTable)
      .where(eq(conferencesTable.id, params.data.id))
      .limit(1);
    if (!conference) {
      res.status(404).json({ error: "Conference not found." });
      return;
    }
    res.json(GetConferenceResponse.parse(conference));
  },
);

router.patch(
  "/conferences/:id",
  requireNetworkAdmin,
  async (req, res): Promise<void> => {
    const params = UpdateConferenceParams.safeParse(req.params);
    const input = UpdateConferenceBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!input.success) {
      res.status(400).json({ error: input.error.message });
      return;
    }
    const data = input.data;
    const [updated] = await db
      .update(conferencesTable)
      .set({
        ...(data.name !== undefined ? { name: data.name.trim() } : {}),
        ...(data.level !== undefined ? { level: data.level } : {}),
        ...(data.city !== undefined ? { city: data.city.trim() } : {}),
        ...(data.region !== undefined ? { region: data.region.trim() } : {}),
        ...(data.venue !== undefined ? { venue: data.venue } : {}),
        ...(data.startDate !== undefined
          ? { startDate: toDateValue(data.startDate)! }
          : {}),
        ...(data.endDate !== undefined
          ? { endDate: toDateValue(data.endDate)! }
          : {}),
        ...(data.applicationDeadline !== undefined
          ? { applicationDeadline: toDateValue(data.applicationDeadline) }
          : {}),
        ...(data.theme !== undefined ? { theme: data.theme } : {}),
        ...(data.description !== undefined
          ? { description: data.description }
          : {}),
        ...(data.fee !== undefined ? { fee: data.fee } : {}),
      })
      .where(eq(conferencesTable.id, params.data.id))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Conference not found." });
      return;
    }
    await audit(
      getAuth(req).userId!,
      "conference.updated",
      "conference",
      String(updated.id),
    );
    res.json(UpdateConferenceResponse.parse(updated));
  },
);

router.delete(
  "/conferences/:id",
  requireNetworkAdmin,
  async (req, res): Promise<void> => {
    const params = ArchiveConferenceParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [archived] = await db
      .update(conferencesTable)
      .set({ status: "archived" })
      .where(eq(conferencesTable.id, params.data.id))
      .returning({ id: conferencesTable.id });
    if (!archived) {
      res.status(404).json({ error: "Conference not found." });
      return;
    }
    await audit(
      getAuth(req).userId!,
      "conference.archived",
      "conference",
      String(archived.id),
    );
    res.sendStatus(204);
  },
);

router.patch(
  "/conferences/:id/publish",
  requireNetworkAdmin,
  async (req, res): Promise<void> => {
    const params = SetConferencePublishedParams.safeParse(req.params);
    const input = SetConferencePublishedBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!input.success) {
      res.status(400).json({ error: input.error.message });
      return;
    }
    const [updated] = await db
      .update(conferencesTable)
      .set({ status: input.data.published ? "published" : "draft" })
      .where(eq(conferencesTable.id, params.data.id))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Conference not found." });
      return;
    }
    await audit(
      getAuth(req).userId!,
      input.data.published ? "conference.published" : "conference.unpublished",
      "conference",
      String(updated.id),
    );
    res.json(SetConferencePublishedResponse.parse(updated));
  },
);

router.get("/public/conferences", async (_req, res): Promise<void> => {
  const conferences = await db
    .select()
    .from(conferencesTable)
    .where(eq(conferencesTable.status, "published"))
    .orderBy(asc(conferencesTable.startDate));
  res.json(ListPublicConferencesResponse.parse(conferences));
});

router.get(
  "/public/conferences/:slug",
  async (req, res): Promise<void> => {
    const params = GetPublicConferenceParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [conference] = await db
      .select()
      .from(conferencesTable)
      .where(
        and(
          eq(conferencesTable.slug, params.data.slug),
          eq(conferencesTable.status, "published"),
        ),
      )
      .limit(1);
    if (!conference) {
      res.status(404).json({ error: "Conference not found." });
      return;
    }
    const committees = await db
      .select()
      .from(committeesTable)
      .where(
        and(
          eq(committeesTable.conferenceId, conference.id),
          eq(committeesTable.published, true),
        ),
      )
      .orderBy(asc(committeesTable.name));
    res.json(GetPublicConferenceResponse.parse({ ...conference, committees }));
  },
);

router.get(
  "/conferences/:id/committees",
  requireNetworkAdmin,
  async (req, res): Promise<void> => {
    const params = ListCommitteesParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const committees = await db
      .select()
      .from(committeesTable)
      .where(eq(committeesTable.conferenceId, params.data.id))
      .orderBy(asc(committeesTable.name));
    res.json(ListCommitteesResponse.parse(committees));
  },
);

router.post(
  "/conferences/:id/committees",
  requireNetworkAdmin,
  async (req, res): Promise<void> => {
    const params = CreateCommitteeParams.safeParse(req.params);
    const input = CreateCommitteeBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!input.success) {
      res.status(400).json({ error: input.error.message });
      return;
    }
    const [conference] = await db
      .select({ id: conferencesTable.id })
      .from(conferencesTable)
      .where(eq(conferencesTable.id, params.data.id))
      .limit(1);
    if (!conference) {
      res.status(404).json({ error: "Conference not found." });
      return;
    }
    const [created] = await db
      .insert(committeesTable)
      .values({
        conferenceId: params.data.id,
        name: input.data.name.trim(),
        topic: input.data.topic ?? null,
        description: input.data.description ?? null,
        chair: input.data.chair ?? null,
        studyGuideUrl: input.data.studyGuideUrl ?? null,
      })
      .returning();
    await audit(
      getAuth(req).userId!,
      "committee.created",
      "committee",
      String(created.id),
    );
    res.status(201).json(CreateCommitteeResponse.parse(created));
  },
);

router.get(
  "/admin/applications",
  requireNetworkAdmin,
  async (_req, res): Promise<void> => {
    const applications = await db
      .select()
      .from(applicationsTable)
      .orderBy(desc(applicationsTable.receivedAt));
    res.json(ListApplicationsResponse.parse(applications));
  },
);

export default router;
