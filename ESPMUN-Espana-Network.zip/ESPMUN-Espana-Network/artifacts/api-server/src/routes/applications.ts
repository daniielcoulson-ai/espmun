import { getAuth } from "@clerk/express";
import { and, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  SubmitApplicationBody,
  SubmitApplicationResponse,
  UpdateApplicationBody,
  UpdateApplicationParams,
  UpdateApplicationResponse,
} from "@workspace/api-zod";
import {
  applicationsTable,
  auditLogsTable,
  conferencesTable,
  db,
} from "@workspace/db";
import { requireNetworkAdmin } from "../middlewares/adminAuth";

const router: IRouter = Router();

router.post("/applications", async (req, res): Promise<void> => {
  const input = SubmitApplicationBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: input.error.message });
    return;
  }
  const [conference] = await db
    .select()
    .from(conferencesTable)
    .where(
      and(
        eq(conferencesTable.id, input.data.conferenceId),
        eq(conferencesTable.status, "published"),
      ),
    )
    .limit(1);
  if (!conference) {
    res.status(404).json({ error: "Applications are not open for this conference." });
    return;
  }
  const today = new Date().toISOString().slice(0, 10);
  if (conference.applicationDeadline && conference.applicationDeadline < today) {
    res.status(409).json({ error: "The application deadline has passed." });
    return;
  }
  const [created] = await db
    .insert(applicationsTable)
    .values({
      conferenceId: input.data.conferenceId,
      fullName: input.data.fullName.trim(),
      email: input.data.email.trim().toLowerCase(),
      applicantType: input.data.applicantType,
      school: input.data.school ?? null,
      message: input.data.message ?? null,
    })
    .returning();
  res.status(201).json(
    SubmitApplicationResponse.parse({
      id: created.id,
      status: created.status,
      receivedAt: created.receivedAt,
    }),
  );
});

router.patch(
  "/admin/applications/:id",
  requireNetworkAdmin,
  async (req, res): Promise<void> => {
    const params = UpdateApplicationParams.safeParse(req.params);
    const input = UpdateApplicationBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!input.success) {
      res.status(400).json({ error: input.error.message });
      return;
    }
    const [updated] = await db
      .update(applicationsTable)
      .set({ status: input.data.status })
      .where(eq(applicationsTable.id, params.data.id))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Application not found." });
      return;
    }
    const actorUserId = getAuth(req).userId!;
    await db.insert(auditLogsTable).values({
      actorUserId,
      action: `application.status.${updated.status}`,
      entityType: "application",
      entityId: String(updated.id),
    });
    res.json(UpdateApplicationResponse.parse(updated));
  },
);

export default router;
