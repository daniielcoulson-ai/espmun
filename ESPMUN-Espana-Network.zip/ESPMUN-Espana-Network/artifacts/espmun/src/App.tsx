import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ClerkProvider, SignIn, SignUp, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ArrowRight, ArrowUpRight, BookOpen, CalendarDays, Check, ChevronRight, CircleHelp, FileText, Landmark, Mail, MapPin, Menu, Plus, Users } from 'lucide-react';
import { Link, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';
import {
  getGetDashboardQueryKey,
  getGetConferenceQueryKey,
  getGetPublicConferenceQueryKey,
  getListApplicationsQueryKey,
  getListCommitteesQueryKey,
  getListConferencesQueryKey,
  getListPublicConferencesQueryKey,
  useArchiveConference,
  useCreateCommittee,
  useCreateConference,
  useGetConference,
  useGetDashboard,
  useGetPublicConference,
  useHealthCheck,
  useListApplications,
  useListCommittees,
  useListConferences,
  useListPublicConferences,
  useSetConferencePublished,
  useSubmitApplication,
  useUpdateApplication,
  useUpdateConference,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import './index.css';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#c52335',
    colorForeground: '#292929',
    colorMutedForeground: '#686868',
    colorDanger: '#b42332',
    colorBackground: '#ffffff',
    colorInput: '#ffffff',
    colorInputForeground: '#292929',
    colorNeutral: '#dedede',
    fontFamily: 'DM Sans, sans-serif',
    borderRadius: '2px',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-white rounded-sm w-[440px] max-w-full overflow-hidden border border-[#dedede]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#292929] font-serif',
    headerSubtitle: 'text-[#686868]',
    socialButtonsBlockButtonText: 'text-[#292929]',
    formFieldLabel: 'text-[#444444]',
    footerActionLink: 'text-[#c52335]',
    footerActionText: 'text-[#686868]',
    dividerText: 'text-[#686868]',
    identityPreviewEditButton: 'text-[#c52335]',
    formFieldSuccessText: 'text-[#356a58]',
    alertText: 'text-[#793c44]',
    logoBox: 'rounded-none',
    logoImage: 'max-h-10',
    socialButtonsBlockButton: 'border-[#dedede] bg-white',
    formButtonPrimary: 'bg-[#c52335] hover:bg-[#a91d2d]',
    formFieldInput: 'border-[#dedede] bg-white text-[#292929]',
    footerAction: 'text-[#686868]',
    dividerLine: 'bg-[#dedede]',
    alert: 'bg-[#fbf1ef] border-[#d5b4b6]',
    otpCodeFieldInput: 'border-[#dedede]',
    formFieldRow: 'text-[#292929]',
    main: 'text-[#292929]',
  },
};

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) client.clear();
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function SignInPage() {
  return <main className="public-wrap grid min-h-[100dvh] place-items-center px-5 py-12"><div><p className="eyebrow mb-6 text-center text-[#c52335]">ESPMUN España · Sign in</p><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div></main>;
}

function SignUpPage() {
  return <main className="public-wrap grid min-h-[100dvh] place-items-center px-5 py-12"><div><p className="eyebrow mb-6 text-center text-[#c52335]">ESPMUN España · Create an account</p><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div></main>;
}

const publicNav = [
  ['/conferences', 'Conferences'],
  ['/network', 'The network'],
  ['/about', 'About'],
  ['/resources', 'Resources'],
  ['/news', 'News'],
];

function Brand({ light = false }: { light?: boolean }) {
  return <Link href="/" className={`brand ${light ? 'text-[#292929]' : ''}`} data-testid="link-brand">
    <span className="brand-mark">E</span><span className="brand-name">ESPMUN<span>ESPAÑA</span></span>
  </Link>;
}

function PublicHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  return <header className="topbar">
    <Brand />
    <nav className="nav-links" aria-label="Main navigation">
      {publicNav.map(([href, label]) => <Link key={href} href={href}>{label}</Link>)}
    </nav>
    <div className="nav-actions">
      <Link href="/student-portal" className="text-link">Student portal</Link>
      <Link href="/join" className="button">Get involved <ArrowUpRight size={14} /></Link>
      <button className="mobile-menu" aria-label="Open menu" data-testid="button-mobile-menu" onClick={() => setMenuOpen(!menuOpen)}><Menu size={20} /></button>
    </div>
    {menuOpen && <nav className="mobile-nav" aria-label="Mobile navigation">{publicNav.map(([href, label]) => <Link key={href} href={href} onClick={() => setMenuOpen(false)}>{label}<ChevronRight size={14} /></Link>)}<Link href="/contact">Contact<ChevronRight size={14} /></Link></nav>}
  </header>;
}

function Footer() {
  return <footer className="site-footer">
    <div className="footer-top">
      <div><Brand light /><p className="mt-5 max-w-sm text-xs leading-6 text-[#686868]">An educational network for Model United Nations, diplomacy and student dialogue.</p></div>
      <div className="footer-links">
        <Link href="/conferences">Conferences</Link><Link href="/network">The network</Link><Link href="/about">About</Link><Link href="/resources">Resources</Link><Link href="/contact">Contact</Link><Link href="/privacy">Privacy</Link>
      </div>
    </div>
    <div className="footer-bottom"><span>© ESPMUN España</span><span>An educational network</span></div>
  </footer>;
}

function PublicLayout({ children }: { children: ReactNode }) {
  return <div className="public-wrap"><PublicHeader />{children}<Footer /></div>;
}

function PageHero({ eyebrow, title, intro }: { eyebrow: string; title: string; intro: string }) {
  return <section className="page-hero"><div className="breadcrumb">{eyebrow}</div><h1>{title}</h1><p>{intro}</p></section>;
}

function LoadingBlock({ label = 'Loading information' }: { label?: string }) {
  return <div className="loading-lines py-5" aria-label={label}><div className="skeleton w-1/3" /><div className="skeleton w-4/5" /><div className="skeleton w-2/3" /></div>;
}

function QueryError({ error, retry }: { error: unknown; retry: () => void }) {
  const code = readStatus(error);
  return <div className="error-box" role="alert">
    <strong>{code === 401 || code === 403 ? 'Access not authorized' : 'Information could not be loaded.'}</strong>
    <span className="block mt-1">{code === 401 ? 'Sign in with an authorized account and try again.' : code === 403 ? 'Your session is not permitted to access this resource. Authorization is determined by the server.' : 'Check your connection and try again.'}</span>
    <button className="table-action mt-3" onClick={retry} data-testid="button-retry">Try again</button>
  </div>;
}

function readStatus(error: unknown): number | undefined {
  if (!error || typeof error !== 'object') return undefined;
  const value = error as { status?: number; response?: { status?: number } };
  return value.status ?? value.response?.status;
}

function formatDate(date?: string | null, options?: Intl.DateTimeFormatOptions) {
  if (!date) return 'Date to be confirmed';
  const parsed = new Date(date);
  if (Number.isNaN(parsed.getTime())) return date;
  return new Intl.DateTimeFormat('en-GB', options ?? { day: 'numeric', month: 'long', year: 'numeric' }).format(parsed);
}

function statusLabel(status: string) {
  const labels: Record<string, string> = { draft: 'Draft', published: 'Published', archived: 'Archived', submitted: 'Submitted', under_review: 'Under review', accepted: 'Accepted', waitlisted: 'Waitlisted', rejected: 'Rejected' };
  return labels[status] ?? status;
}

function applicantLabel(type: string) {
  const labels: Record<string, string> = { delegate: 'Delegate', advisor: 'Teacher adviser', observer: 'Observer' };
  return labels[type] ?? type;
}

function ConferenceCard({ conference }: { conference: any }) {
  return <Link href={`/conference/${conference.slug}`} className="conference-card" data-testid={`card-conference-${conference.id}`}>
    <div><span className="tag">{conference.level}</span><h3>{conference.name}</h3><p><MapPin size={12} className="mr-1 inline" />{conference.city}{conference.region ? ` · ${conference.region}` : ''}</p></div>
    <div className="card-meta"><span><CalendarDays size={12} className="mr-1 inline" />{formatDate(conference.startDate, { day: 'numeric', month: 'short' })} — {formatDate(conference.endDate, { day: 'numeric', month: 'short', year: 'numeric' })}</span><ArrowUpRight size={15} /></div>
  </Link>;
}

function HomePage() {
  const conferences = useListPublicConferences();
  const featured = useMemo(() => (conferences.data ?? []).slice(0, 3), [conferences.data]);
  return <PublicLayout>
    <main>
      <section className="hero">
        <div className="hero-copy fade-up">
          <div className="eyebrow">One network · many voices</div>
          <h1>The world begins in your classroom.</h1>
          <p>ESPMUN España connects students and conference teams to listen, negotiate and build agreements that matter.</p>
          <div className="hero-actions"><Link href="/conferences" className="button">Explore conferences <ArrowRight size={14} /></Link><Link href="/network" className="button secondary">Discover the network</Link></div>
        </div>
        <div className="hero-image"><span className="image-caption">Young diplomacy, a wider view</span></div>
      </section>
      <section className="section split-section">
        <div className="section-heading mb-0"><div className="eyebrow">A shared experience</div><h2>A place to practise the future, today.</h2><p>Model United Nations turns international affairs into an active experience: research, represent different perspectives and work towards shared proposals.</p><Link href="/about" className="mt-5 inline-flex items-center gap-2 text-xs font-semibold text-[#c52335]">Discover ESPMUN España <ArrowRight size={14} /></Link></div>
        <div className="split-quote">“Learning to work through disagreement is also learning to lead.”<small>The value of an MUN simulation</small></div>
      </section>
      <section className="section soft-band">
        <div className="section-heading"><div className="eyebrow">From local to global</div><h2>Five levels. One shared conversation.</h2><p>The network brings together educational communities and opens pathways to international dialogue.</p></div>
        <div className="level-strip">{[['Local','The first conversation'],['Provincial','Connect nearby schools'],['Regional','Share perspectives'],['National','A country in dialogue'],['International','Perspectives without borders']].map(([name, desc]) => <div className="level-item" key={name}><b>{name}</b><span>{desc}</span></div>)}</div>
        <Link href="/network" className="mt-7 inline-flex items-center gap-2 text-xs font-semibold text-[#c52335]">Explore the network levels <ArrowRight size={14} /></Link>
      </section>
      <section className="section">
        <div className="section-heading"><div className="eyebrow">Open agenda</div><h2>Find your next conference.</h2><p>Browse conferences published by their organising teams. Information is updated by the network.</p></div>
        {conferences.isLoading ? <div className="conference-grid">{[1,2,3].map(i => <div key={i} className="conference-card"><LoadingBlock /></div>)}</div> : conferences.isError ? <QueryError error={conferences.error} retry={() => conferences.refetch()} /> : featured.length ? <div className="conference-grid">{featured.map((item) => <ConferenceCard key={item.id} conference={item} />)}</div> : <EmptyPublic title="No conferences have been published yet." body="Published events will appear here as organising teams add them." />}
        <Link href="/conferences" className="mt-7 inline-flex items-center gap-2 text-xs font-semibold text-[#c52335]">Browse the full directory <ArrowRight size={14} /></Link>
      </section>
      <section className="section cta-band"><div><div className="eyebrow text-[#c52335]">Your place in the conversation</div><h2>A delegation, a conference or an idea: start here.</h2></div><Link href="/join" className="button secondary">How to take part <ArrowUpRight size={14} /></Link></section>
    </main>
  </PublicLayout>;
}

function EmptyPublic({ title, body }: { title: string; body: string }) {
  return <div className="notice py-8 text-center"><h3 className="serif text-xl text-[#102b3a]">{title}</h3><p className="mt-2 text-xs">{body}</p></div>;
}

function ConferencesPage() {
  const conferences = useListPublicConferences();
  const [level, setLevel] = useState('All');
  const entries = useMemo(() => (conferences.data ?? []).filter((item) => level === 'All' || item.level === level), [conferences.data, level]);
  return <PublicLayout><PageHero eyebrow="Public directory" title="MUN conferences in Spain." intro="Find published events, explore their themes and review the information shared by each organising team." />
    <section className="section">
      <div className="admin-toolbar mb-7"><span className="eyebrow mr-2">Filter by level</span>{['All','Local','Provincial','Regional','National','International'].map((item) => <button key={item} onClick={() => setLevel(item)} className={`table-action ${level === item ? 'selected' : ''}`} data-testid={`filter-level-${item.toLowerCase()}`}>{item}</button>)}</div>
      {conferences.isLoading ? <LoadingBlock /> : conferences.isError ? <QueryError error={conferences.error} retry={() => conferences.refetch()} /> : entries.length ? <div className="conference-grid">{entries.map((item) => <ConferenceCard key={item.id} conference={item} />)}</div> : <EmptyPublic title="No events match this filter." body="Choose another level or check back later." />}
    </section>
  </PublicLayout>;
}

function ConferencePage() {
  const { slug = '' } = useParams<{ slug: string }>();
  const query = useGetPublicConference(slug, { query: { queryKey: getGetPublicConferenceQueryKey(slug), enabled: !!slug } });
  const submit = useSubmitApplication();
  const [receipt, setReceipt] = useState<{ id: number; status: string; receivedAt: string } | null>(null);
  const [submitError, setSubmitError] = useState('');
  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitError('');
    const form = new FormData(event.currentTarget);
    const data = {
      conferenceId: Number(form.get('conferenceId')),
      fullName: String(form.get('fullName') ?? '').trim(),
      email: String(form.get('email') ?? '').trim(),
      applicantType: String(form.get('applicantType') ?? 'delegate') as 'delegate' | 'advisor' | 'observer',
      school: String(form.get('school') ?? '').trim() || null,
      message: String(form.get('message') ?? '').trim() || null,
    };
    submit.mutate({ data }, { onSuccess: (response) => setReceipt(response), onError: () => setSubmitError('Your application could not be submitted. Check the details and try again.') });
  }
  if (query.isLoading) return <PublicLayout><section className="section"><LoadingBlock /></section></PublicLayout>;
  if (query.isError || !query.data) return <PublicLayout><section className="section"><QueryError error={query.error} retry={() => query.refetch()} /></section></PublicLayout>;
  const conference = query.data;
  return <PublicLayout>
    <PageHero eyebrow={`${conference.level} · ${conference.city}`} title={conference.name} intro={conference.description || 'The organising team has not added a description for this conference yet.'} />
    <section className="section split-section">
      <div><div className="eyebrow text-[#c52335]">Conference details</div><h2 className="serif mt-4 text-3xl">{conference.theme || 'Theme to be announced'}</h2><div className="mt-8 grid gap-5 text-sm text-[#555555]">
        <p><CalendarDays size={16} className="mr-2 inline" />{formatDate(conference.startDate)} — {formatDate(conference.endDate)}</p>
        <p><MapPin size={16} className="mr-2 inline" />{conference.venue ? `${conference.venue}, ` : ''}{conference.city}, {conference.region}</p>
        <p><CircleHelp size={16} className="mr-2 inline" />Application deadline: {formatDate(conference.applicationDeadline)}</p>
        {conference.fee != null && <p>Fee listed by the organisers: {new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'EUR' }).format(conference.fee)}</p>}
      </div></div>
      <div className="form-shell">
        <div className="eyebrow text-[#c52335]">Take part</div><h2 className="serif mt-3 text-3xl">Apply to attend</h2>
        {receipt ? <div className="notice mt-6" role="status"><Check size={18} className="mb-2" /><strong className="block">Application received</strong><span>Reference {receipt.id} · Status: {statusLabel(receipt.status)} · {formatDate(receipt.receivedAt)}</span></div> :
          <form onSubmit={onSubmit} className="mt-6">
            <input type="hidden" name="conferenceId" value={conference.id} />
            <div className="field"><label htmlFor="app-name">Full name</label><input required minLength={2} id="app-name" name="fullName" data-testid="input-application-name" /></div>
            <div className="field"><label htmlFor="app-email">Email address</label><input required type="email" id="app-email" name="email" data-testid="input-application-email" /></div>
            <div className="form-grid"><div className="field"><label htmlFor="app-type">Applicant type</label><select id="app-type" name="applicantType"><option value="delegate">Delegate</option><option value="advisor">Teacher adviser</option><option value="observer">Observer</option></select></div><div className="field"><label htmlFor="app-school">School</label><input id="app-school" name="school" /></div></div>
            <div className="field"><label htmlFor="app-message">Message (optional)</label><textarea id="app-message" name="message" /></div>
            {submitError && <div className="error-box mb-4">{submitError}</div>}
            <button className="button w-full" type="submit" disabled={submit.isPending} data-testid="button-submit-application">{submit.isPending ? 'Submitting application…' : 'Submit application'} <ArrowRight size={14} /></button>
            <p className="mt-3 text-[10px] leading-5 text-[#686868]">Your application will be sent to the organising team for review. Read our <Link href="/privacy" className="underline">privacy notice</Link>.</p>
          </form>}
      </div>
    </section>
    <section className="section soft-band"><div className="section-heading"><div className="eyebrow">Committees</div><h2>The working groups.</h2><p>Topics and study materials published by the organising team appear here.</p></div>
      {conference.committees?.length ? <div className="conference-grid">{conference.committees.filter((committee: any) => committee.published).map((committee: any) => <article key={committee.id} className="conference-card"><div><span className="tag">Committee</span><h3>{committee.name}</h3><p>{committee.topic || committee.description || 'More information will be added by the organising team.'}</p></div>{committee.studyGuideUrl && <a className="card-meta" href={committee.studyGuideUrl} target="_blank" rel="noreferrer">Study guide <ArrowUpRight size={14} /></a>}</article>)}</div> : <EmptyPublic title="Committees have not been published yet." body="The organising team can add committees and materials to this page." />}
    </section>
  </PublicLayout>;
}

function NetworkPage() {
  const levels = [
    ['01','Local','A starting point: an educational community meeting to debate global issues.'],
    ['02','Provincial','Teams from nearby municipalities share practice, learning and organisation.'],
    ['03','Regional','A wider conversation shaped by the perspectives and priorities of each region.'],
    ['04','National','Delegations from across Spain compare perspectives and build shared proposals.'],
    ['05','International','Dialogue crosses borders and connects experiences from different countries.'],
  ];
  return <PublicLayout><PageHero eyebrow="How the network works" title="From your school to international dialogue." intro="ESPMUN España connects MUN initiatives while respecting their local context and creating opportunities for teams to collaborate." />
    <section className="section"><div className="prose-block"><h2>A network built from the ground up.</h2><p>Every conference has its own identity, themes and community. The network connects those experiences, shares knowledge and helps more students find their first place at the table.</p><p>These levels describe opportunities to meet, not a hierarchy of value. Each team decides how to take part and which scale makes sense for its community.</p></div>
      <div className="network-steps">{levels.map(([number, name, description]) => <article className="network-step" key={name}><span>{number} / LEVEL</span><h3>{name}</h3><p>{description}</p></article>)}</div>
    </section>
    <section className="section cta-band"><div><div className="eyebrow text-[#c52335]">A network in motion</div><h2>Looking to connect your initiative with others?</h2></div><Link href="/join" className="button secondary">Join the network <ArrowRight size={14} /></Link></section>
  </PublicLayout>;
}

function AboutPage() {
  return <PublicLayout><PageHero eyebrow="About us" title="Learn democracy by practising it." intro="ESPMUN España is an educational network for Model United Nations: simulations that bring diplomacy and global affairs to students across Spain." />
    <section className="section"><div className="prose-block"><h2>A practice, not just an event.</h2><p>In an MUN simulation, each participant represents a delegation, researches an international agenda and negotiates with others to develop proposals. The process calls for preparation, listening and rigour; the outcome matters, and so does how it is reached.</p><h2>What we want to make possible</h2><p>Connect students and organising teams, make existing activity more visible and help new communities launch their own experiences.</p><h2>A network open to learning</h2><p>The network is built with schools, students, teachers and conference teams. Each event keeps its autonomy and contributes its own perspective.</p></div></section>
    <section className="section soft-band"><div className="section-heading"><div className="eyebrow">Our principles</div><h2>Rigour in debate. Openness in listening.</h2></div><div className="level-strip">{[['Preparation','Research before representing.'],['Respect','Listen without flattening differences.'],['Collaboration','Look beyond initial positions.'],['Access','Make room for new voices.'],['Responsibility','Take care of the process and its agreements.']].map(([x,y])=><div className="level-item" key={x}><b>{x}</b><span>{y}</span></div>)}</div></section>
  </PublicLayout>;
}

function ResourcesPage() {
  return <PublicLayout><PageHero eyebrow="Working library" title="Tools to prepare for the conversation." intro="A strong simulation begins well before the session opens: with questions, reliable sources, listening and a shared structure." />
    <section className="section"><div className="conference-grid">
      {[['Research an agenda','Define the issue, identify primary sources and compare perspectives.','Research'],['Represent a delegation','Build an informed position without confusing it with a personal opinion.','Preparation'],['Negotiate a draft','Turn positions into clear, workable and negotiable proposals.','Procedure']].map(([title, text, tag])=><article className="conference-card" key={title}><div><span className="tag">{tag}</span><h3>{title}</h3><p>{text}</p></div><div className="card-meta">Introductory guide <BookOpen size={14} /></div></article>)}
    </div><div className="notice mt-8"><strong>Library in development.</strong> These principles are editorial guidance; downloadable materials will be added when the team publishes verified resources.</div></section>
  </PublicLayout>;
}

function NewsPage() {
  return <PublicLayout><PageHero eyebrow="News" title="What is happening across the network." intro="Updates and announcements published by ESPMUN España and its collaborating teams." /><section className="section"><EmptyPublic title="There are no published news items yet." body="Verified updates will appear here when available." /></section></PublicLayout>;
}

function ContactPage() {
  return <PublicLayout><PageHero eyebrow="Contact" title="Let's talk about the network." intro="If you represent a school, delegation or organising team, we would like to learn about the work you are building." /><section className="section"><div className="form-shell text-center"><Mail size={24} className="mx-auto text-[#c52335]" /><h2 className="serif mt-4 text-3xl">Contact channel</h2><p className="mt-3 text-sm leading-7 text-[#555555]">The official contact channel has not been published yet. No contact form is available at the moment; it will appear here once the team confirms its official address.</p><Link href="/join" className="button secondary mt-6">Find out how to take part</Link></div></section></PublicLayout>;
}

function JoinPage() {
  return <PublicLayout><PageHero eyebrow="Take part" title="Your experience can start here." intro="There are many ways to join an MUN community. The first step depends on who you are and what you want to build." />
    <section className="section"><div className="conference-grid">
      {[['I am a student','Find a published conference and check its participation details.','/conferences','Browse conferences'],['I am a teacher','Connect your school to the network and explore ways to collaborate.','/network','Explore the network'],['I organise a conference','Share your event and official information with prospective delegations.','/contact','Contact the team']].map(([title,text,href,action])=><article className="conference-card" key={title}><div><span className="tag">ESPMUN España</span><h3>{title}</h3><p>{text}</p></div><Link href={href} className="card-meta">{action}<ArrowUpRight size={14} /></Link></article>)}
    </div><div className="notice mt-7">Students can sign in to their account. An application is not a confirmed place until the conference organisers have reviewed it.</div></section>
  </PublicLayout>;
}

function StudentPortalPage() {
  return <PublicLayout><PageHero eyebrow="Student portal" title="Your place in the network." intro="Sign in to continue. Applications to conferences are submitted from each event's public page." /><section className="section"><div className="form-shell text-center"><Users size={25} className="mx-auto text-[#c52335]" /><h2 className="serif mt-4 text-3xl">Student access</h2><p className="mt-3 text-sm leading-7 text-[#555555]">Sign in with your ESPMUN España account. Available features depend on the services connected to your account.</p><Link href="/sign-in" className="button mt-6">Sign in <ArrowRight size={14} /></Link></div></section></PublicLayout>;
}

function PrivacyPage() {
  return <PublicLayout><PageHero eyebrow="Privacy" title="Your data, handled with care." intro="This page explains in general terms what happens to the information you submit when applying to a conference." /><section className="section"><div className="prose-block"><h2>Applications</h2><p>When someone submits an application from a conference page, the information provided is sent to the ESPMUN España service for registration and review by the relevant organising team.</p><h2>How information is used</h2><p>The requested details — name, email, applicant type, school and optional message — are used to process the application and support communication about that conference. Do not include sensitive information in the message field.</p><h2>Retention and enquiries</h2><p>Retention periods, the legal identity of the data controller and the channel for exercising data rights must be confirmed and published by the responsible organisation before the service launches at scale. This page is not a substitute for a complete legal notice.</p><div className="notice mt-8">Notice: the legal data controller and official contact details have not yet been published.</div></div></section></PublicLayout>;
}

function AdminBrand() {
  return <Link href="/admin" className="brand"><span className="brand-mark">E</span><span className="brand-name">ESPMUN<span>OPERATIONS</span></span></Link>;
}

function AdminShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const items = [['/admin','Dashboard',Landmark],['/admin/conferences','Conferences',CalendarDays],['/admin/applications','Applications',FileText]] as const;
  return <div className="admin-shell">
    <aside className="admin-side"><AdminBrand /><nav className="admin-nav" aria-label="Admin navigation">{items.map(([href,label,Icon]) => <Link key={href} href={href} className={location === href ? 'active' : ''} data-testid={`admin-nav-${label.toLowerCase()}`}><Icon size={16} /><span>{label}</span></Link>)}</nav><div className="admin-side-note">ESPMUN España operations workspace.<br />Access is checked by the server.</div></aside>
    <div className="admin-main"><header className="admin-top"><span>ESPMUN España / Operations</span><Link href="/" className="text-xs text-[#c52335]">Back to public site <ArrowUpRight size={12} className="ml-1 inline" /></Link></header>{children}</div>
  </div>;
}

function AdminDenied({ error, refetch }: { error: unknown; refetch: () => void }) {
  const status = readStatus(error);
  return <div className="admin-content"><div className="admin-heading"><div><div className="eyebrow text-[#c52335]">Server authorization</div><h1>Operations workspace access</h1></div></div><div className="error-box max-w-2xl"><strong>{status === 401 ? 'Sign-in is required.' : status === 403 ? 'This account is not authorized to access this area.' : 'The operations workspace could not be reached.'}</strong><p className="mt-2">{status === 401 ? 'Sign in and try again. Administrator access is determined by the server.' : status === 403 ? 'Your session is active, but the server has not authorized this operation. No permissions are inferred in the browser.' : 'Try again when the service is available.'}</p><div className="mt-4 flex gap-3"><button className="table-action" onClick={refetch}>Try again</button>{status === 401 && <Link href="/sign-in" className="table-action">Sign in</Link>}</div></div></div>;
}

function DashboardPage() {
  const dashboard = useGetDashboard();
  const health = useHealthCheck();
  if (dashboard.isLoading) return <AdminShell><div className="admin-content"><LoadingBlock /></div></AdminShell>;
  if (dashboard.isError || !dashboard.data) return <AdminShell><AdminDenied error={dashboard.error} refetch={() => dashboard.refetch()} /></AdminShell>;
  const data = dashboard.data;
  const levelNames = ['Local','Provincial','Regional','National','International'] as const;
  return <AdminShell><main className="admin-content">
    <div className="admin-heading"><div><div className="eyebrow text-[#c52335]">Overview</div><h1>Network at a glance.</h1><p>Live totals and upcoming conferences, provided by the service.</p></div><span className="text-[10px] text-[#686868]">Service {health.data?.status ?? (health.isError ? 'unavailable' : '…')}</span></div>
    <div className="metric-grid">{[['Conferences',data.conferenceTotal],['Published',data.publishedTotal],['Drafts',data.draftTotal],['Applications',data.applicationTotal]].map(([title,value])=><div className="metric" key={title}><span>{title}</span><strong>{value}</strong></div>)}</div>
    <div className="admin-panel"><div className="admin-panel-head"><h2>Conferences by level</h2></div><div className="level-strip">{levelNames.map(level=><div className="level-item" key={level}><b>{level}</b><span>{data.byLevel[level]} conferences</span></div>)}</div></div>
    <div className="admin-panel"><div className="admin-panel-head"><h2>Upcoming conferences</h2><Link href="/admin/conferences" className="text-xs text-[#c52335]">Manage <ArrowRight size={12} className="ml-1 inline" /></Link></div>
      {data.upcoming.length ? <div className="table-wrap"><table className="admin-table"><thead><tr><th>Conference</th><th>Level</th><th>City</th><th>Start date</th><th>Status</th></tr></thead><tbody>{data.upcoming.map((conference:any)=><tr key={conference.id}><td><strong>{conference.name}</strong></td><td>{conference.level}</td><td>{conference.city}</td><td>{formatDate(conference.startDate)}</td><td><span className={`status-pill ${conference.status}`}>{statusLabel(conference.status)}</span></td></tr>)}</tbody></table></div> : <EmptyPublic title="No upcoming conferences." body="Conferences recorded by the service will appear here." />}
    </div>
  </main></AdminShell>;
}

const levelValues = ['Local','Provincial','Regional','National','International'] as const;

function ConferenceForm({ initial, onSubmit, busy, submitText }: { initial?: any; onSubmit: (data: any) => void; busy: boolean; submitText: string }) {
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const f = new FormData(event.currentTarget);
    const form = {
      name: String(f.get('name') ?? '').trim(),
      level: String(f.get('level') ?? 'Local'),
      city: String(f.get('city') ?? '').trim(),
      region: String(f.get('region') ?? '').trim(),
      venue: String(f.get('venue') ?? '').trim() || null,
      startDate: String(f.get('startDate') ?? ''),
      endDate: String(f.get('endDate') ?? ''),
      applicationDeadline: String(f.get('applicationDeadline') ?? '') || null,
      theme: String(f.get('theme') ?? '').trim() || null,
      description: String(f.get('description') ?? '').trim() || null,
      fee: String(f.get('fee') ?? '') === '' ? null : Number(f.get('fee')),
    };
    onSubmit(form);
  }
  return <form onSubmit={submit} className="inline-form">
    <div className="field"><label>Name</label><input name="name" required minLength={2} defaultValue={initial?.name ?? ''} data-testid="input-conf-name" /></div>
    <div className="field"><label>Level</label><select name="level" defaultValue={initial?.level ?? 'Local'}>{levelValues.map(level=><option value={level} key={level}>{level}</option>)}</select></div>
    <div className="field"><label>City</label><input name="city" required defaultValue={initial?.city ?? ''} /></div>
    <div className="field"><label>Region</label><input name="region" required defaultValue={initial?.region ?? ''} /></div>
    <div className="field"><label>Venue (optional)</label><input name="venue" defaultValue={initial?.venue ?? ''} /></div>
    <div className="field"><label>Theme</label><input name="theme" defaultValue={initial?.theme ?? ''} /></div>
    <div className="field"><label>Start date</label><input type="date" name="startDate" required defaultValue={initial?.startDate?.slice(0,10) ?? ''} /></div>
    <div className="field"><label>End date</label><input type="date" name="endDate" required defaultValue={initial?.endDate?.slice(0,10) ?? ''} /></div>
    <div className="field"><label>Application deadline</label><input type="date" name="applicationDeadline" defaultValue={initial?.applicationDeadline?.slice(0,10) ?? ''} /></div>
    <div className="field"><label>Fee (EUR)</label><input type="number" name="fee" min="0" step="0.01" defaultValue={initial?.fee ?? ''} /></div>
    <div className="field span2"><label>Description</label><textarea name="description" defaultValue={initial?.description ?? ''} /></div>
    <div className="span2 flex flex-wrap gap-2 pt-2"><button type="submit" disabled={busy} className="button" data-testid="button-save-conference">{busy ? 'Saving…' : submitText}</button></div>
  </form>;
}

function ConferenceEditor({ item, onSubmit, busy, onClose }: { item: any; onSubmit: (data: any) => void; busy: boolean; onClose: () => void }) {
  const detail = useGetConference(item.id, { query: { queryKey: getGetConferenceQueryKey(item.id) } });
  if (detail.isLoading) return <div className="admin-panel"><LoadingBlock label="Loading conference for editing" /></div>;
  if (detail.isError || !detail.data) return <div className="admin-panel"><AdminDenied error={detail.error} refetch={() => detail.refetch()} /></div>;
  return <div className="admin-panel"><div className="admin-panel-head"><h2>Edit · {detail.data.name}</h2><button className="table-action" onClick={onClose}>Close</button></div><ConferenceForm key={detail.data.id} initial={detail.data} onSubmit={onSubmit} busy={busy} submitText="Save changes" /></div>;
}

function ConferencesAdminPage() {
  const queryClient = useQueryClient();
  const list = useListConferences();
  const create = useCreateConference();
  const update = useUpdateConference();
  const publish = useSetConferencePublished();
  const archive = useArchiveConference();
  const createCommittee = useCreateCommittee();
  const [newOpen, setNewOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [selectedForCommittee, setSelectedForCommittee] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: getListConferencesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListPublicConferencesQueryKey() });
  };
  function createItem(data: any) {
    setError('');
    create.mutate({ data }, { onSuccess: () => { setNewOpen(false); refresh(); }, onError: (e) => setError(`Draft could not be created. ${readStatus(e) === 401 ? 'Sign in.' : readStatus(e) === 403 ? 'The server has not authorized this operation.' : 'Check the details and try again.'}`) });
  }
  function updateItem(data: any) {
    if (!editing) return;
    setError('');
    update.mutate({ id: editing.id, data }, { onSuccess: () => { setEditing(null); refresh(); }, onError: (e) => setError(`Changes could not be saved. ${readStatus(e) === 403 ? 'The server has not authorized this operation.' : 'Try again.'}`) });
  }
  function publishItem(item: any) {
    setError('');
    publish.mutate({ id: item.id, data: { published: item.status !== 'published' } }, { onSuccess: refresh, onError: (e) => setError(`Publication status could not be changed. ${readStatus(e) === 403 ? 'The server has not authorized this operation.' : 'Try again.'}`) });
  }
  function archiveItem(item: any) {
    if (!window.confirm(`Archive “${item.name}”? This will remove the conference from the public directory.`)) return;
    setError('');
    archive.mutate({ id: item.id }, { onSuccess: refresh, onError: (e) => setError(`The conference could not be archived. ${readStatus(e) === 403 ? 'The server has not authorized this operation.' : 'Try again.'}`) });
  }
  const entries = useMemo(() => (list.data ?? []).filter((item:any) => `${item.name} ${item.city} ${item.region}`.toLowerCase().includes(search.toLowerCase())), [list.data, search]);
  if (list.isLoading) return <AdminShell><div className="admin-content"><LoadingBlock /></div></AdminShell>;
  if (list.isError) return <AdminShell><AdminDenied error={list.error} refetch={() => list.refetch()} /></AdminShell>;
  return <AdminShell><main className="admin-content">
    <div className="admin-heading"><div><div className="eyebrow text-[#c52335]">Operations / conferences</div><h1>Conferences</h1><p>Manage drafts, public details and publication status.</p></div><button className="button" onClick={() => { setNewOpen(!newOpen); setEditing(null); }} data-testid="button-new-conference"><Plus size={14} /> New draft</button></div>
    {error && <div className="error-box mb-4">{error}</div>}
    {newOpen && <div className="admin-panel"><div className="admin-panel-head"><h2>Create a conference</h2><button className="table-action" onClick={() => setNewOpen(false)}>Close</button></div><p className="mb-5 text-xs text-[#686868]">The service will create a draft. It will not be visible publicly until published.</p><ConferenceForm onSubmit={createItem} busy={create.isPending} submitText="Create draft" /></div>}
    {editing && <ConferenceEditor item={editing} onSubmit={updateItem} busy={update.isPending} onClose={() => setEditing(null)} />}
    <div className="admin-panel"><div className="admin-panel-head"><h2>Conference register</h2><input className="search-input" placeholder="Search by name or city" aria-label="Search conferences by name or city" value={search} onChange={(e) => setSearch(e.target.value)} data-testid="input-conference-search" /></div>
      {entries.length ? <div className="table-wrap"><table className="admin-table"><thead><tr><th>Conference</th><th>Level / city</th><th>Dates</th><th>Status</th><th>Actions</th></tr></thead><tbody>{entries.map((item:any)=><tr key={item.id}><td><strong>{item.name}</strong><div className="mt-1 text-[10px] text-[#686868]">Updated {formatDate(item.updatedAt)}</div></td><td>{item.level}<div className="mt-1 text-[10px]">{item.city}, {item.region}</div></td><td>{formatDate(item.startDate, { day:'numeric',month:'short',year:'numeric' })}<div className="mt-1 text-[10px]">to {formatDate(item.endDate,{day:'numeric',month:'short',year:'numeric'})}</div></td><td><span className={`status-pill ${item.status}`}>{statusLabel(item.status)}</span></td><td><button className="table-action" onClick={() => { setEditing(item); setNewOpen(false); }} data-testid={`edit-conference-${item.id}`}>Edit</button>{item.status !== 'archived' && <><button className="table-action" onClick={() => publishItem(item)} disabled={publish.isPending} data-testid={`publish-conference-${item.id}`}>{item.status === 'published' ? 'Unpublish' : 'Publish'}</button><button className="table-action" onClick={() => archiveItem(item)} disabled={archive.isPending} data-testid={`archive-conference-${item.id}`}>Archive</button></>}</td></tr>)}</tbody></table></div> : <EmptyPublic title="No conferences to show." body="Create a draft to start a conference record." />}
    </div>
    <div className="admin-panel"><div className="admin-panel-head"><h2>Committees</h2><span className="text-[10px] text-[#686868]">Committee creation is available; editing and deletion are not supported by the API.</span></div>
      <div className="field max-w-sm"><label htmlFor="committee-conference">Conference</label><select id="committee-conference" aria-label="Select a conference for committee management" value={selectedForCommittee ?? ''} onChange={(e) => setSelectedForCommittee(Number(e.target.value) || null)}><option value="">Select a conference</option>{(list.data ?? []).filter((item:any)=>item.status !== 'archived').map((item:any)=><option key={item.id} value={item.id}>{item.name}</option>)}</select></div>
      {selectedForCommittee && <CommitteeWorkspace id={selectedForCommittee} onCreate={(data, done) => createCommittee.mutate({ id: selectedForCommittee, data }, { onSuccess: () => { void queryClient.invalidateQueries({ queryKey: getListCommitteesQueryKey(selectedForCommittee) }); done(); }, onError: (e) => setError(`Committee could not be created. ${readStatus(e) === 403 ? 'The server has not authorized this operation.' : 'Try again.'}`) })} busy={createCommittee.isPending} />}
    </div>
  </main></AdminShell>;
}

function CommitteeWorkspace({ id, onCreate, busy }: { id: number; onCreate: (data: any, done: () => void) => void; busy: boolean }) {
  const committees = useListCommittees(id, { query: { queryKey: getListCommitteesQueryKey(id), enabled: !!id } });
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const f = new FormData(event.currentTarget);
    const form = event.currentTarget;
    onCreate({ name: String(f.get('name')).trim(), topic: String(f.get('topic')).trim() || null, description: String(f.get('description')).trim() || null, chair: String(f.get('chair')).trim() || null, studyGuideUrl: String(f.get('studyGuideUrl')).trim() || null }, () => form.reset());
  }
  return <div className="mt-5">
    {committees.isLoading ? <LoadingBlock /> : committees.isError ? <QueryError error={committees.error} retry={() => committees.refetch()} /> : committees.data?.length ? <div className="mb-5 flex flex-wrap gap-2">{committees.data.map((item:any)=><span key={item.id} className="tag">{item.name} · {item.published ? 'Published' : 'Draft'}</span>)}</div> : <p className="mb-5 text-xs text-[#686868]">No committees are registered for this conference.</p>}
    <form onSubmit={submit} className="inline-form border-t border-[#dce2df] pt-5">
      <div className="field"><label>Committee name</label><input required minLength={2} name="name" /></div><div className="field"><label>Topic</label><input name="topic" /></div><div className="field"><label>Chair</label><input name="chair" /></div><div className="field"><label>Study guide URL</label><input type="url" name="studyGuideUrl" /></div><div className="field span2"><label>Description</label><textarea name="description" /></div><div className="span2"><button disabled={busy} className="button" type="submit">{busy ? 'Creating…' : 'Add committee'} <Plus size={13} /></button></div>
    </form>
  </div>;
}

const applicationStatuses = ['submitted','under_review','accepted','waitlisted','rejected'] as const;
function ApplicationsAdminPage() {
  const client = useQueryClient();
  const applications = useListApplications();
  const update = useUpdateApplication();
  const conferences = useListConferences();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');
  const conferenceNames = useMemo(() => new Map((conferences.data ?? []).map((item:any)=>[item.id,item.name])), [conferences.data]);
  const entries = useMemo(() => (applications.data ?? []).filter((app:any) => (filter === 'all' || app.status === filter) && `${app.fullName} ${app.email} ${app.school ?? ''}`.toLowerCase().includes(search.toLowerCase())), [applications.data, filter, search]);
  function changeStatus(id: number, status: typeof applicationStatuses[number]) {
    setMessage('');
    update.mutate({ id, data: { status } }, { onSuccess: () => client.invalidateQueries({ queryKey: getListApplicationsQueryKey() }), onError: (e) => setMessage(readStatus(e) === 403 ? 'The server has not authorized this status change.' : 'The status could not be updated. Please try again.') });
  }
  if (applications.isLoading) return <AdminShell><div className="admin-content"><LoadingBlock /></div></AdminShell>;
  if (applications.isError) return <AdminShell><AdminDenied error={applications.error} refetch={() => applications.refetch()} /></AdminShell>;
  return <AdminShell><main className="admin-content">
    <div className="admin-heading"><div><div className="eyebrow text-[#c52335]">Operations / applications</div><h1>Application review</h1><p>Persisted applications received by the API. Status updates are saved to the service.</p></div></div>
    {message && <div className="error-box mb-4">{message}</div>}
    <div className="admin-panel"><div className="admin-panel-head"><h2>Review queue</h2><div className="admin-toolbar"><input className="search-input" placeholder="Search by name, email or school" aria-label="Search applicants by name, email or school" value={search} onChange={(e)=>setSearch(e.target.value)} /><select className="search-input" value={filter} onChange={(e)=>setFilter(e.target.value)} aria-label="Filter by application status">{['all',...applicationStatuses].map(value=><option value={value} key={value}>{value === 'all' ? 'All statuses' : statusLabel(value)}</option>)}</select></div></div>
      {entries.length ? <div className="table-wrap"><table className="admin-table"><thead><tr><th>Applicant</th><th>Conference</th><th>Applicant type</th><th>Received</th><th>Status</th><th>Update status</th></tr></thead><tbody>{entries.map((app:any)=><tr key={app.id}><td><strong>{app.fullName}</strong><div className="mt-1 text-[10px]">{app.email}</div>{app.school && <div className="mt-1 text-[10px]">{app.school}</div>}</td><td>{conferenceNames.get(app.conferenceId) ?? `Conference #${app.conferenceId}`}</td><td>{applicantLabel(app.applicantType)}</td><td>{formatDate(app.receivedAt)}</td><td><span className={`status-pill ${app.status}`}>{statusLabel(app.status)}</span></td><td><select aria-label={`Status for ${app.fullName}`} className="search-input min-w-[130px]" value={app.status} onChange={(e)=>changeStatus(app.id,e.target.value as typeof applicationStatuses[number])} disabled={update.isPending} data-testid={`select-application-status-${app.id}`}>{applicationStatuses.map(value=><option value={value} key={value}>{statusLabel(value)}</option>)}</select></td></tr>)}</tbody></table></div> : <EmptyPublic title="The review queue is empty." body="No applications match this filter." />}
    </div>
  </main></AdminShell>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch>
    <Route path="/" component={HomePage} />
    <Route path="/conferences" component={ConferencesPage} />
    <Route path="/conference/:slug" component={ConferencePage} />
    <Route path="/network" component={NetworkPage} />
    <Route path="/about" component={AboutPage} />
    <Route path="/resources" component={ResourcesPage} />
    <Route path="/news" component={NewsPage} />
    <Route path="/contact" component={ContactPage} />
    <Route path="/join" component={JoinPage} />
    <Route path="/student-portal" component={StudentPortalPage} />
    <Route path="/privacy" component={PrivacyPage} />
    <Route path="/admin" component={DashboardPage} />
    <Route path="/admin/conferences" component={ConferencesAdminPage} />
    <Route path="/admin/applications" component={ApplicationsAdminPage} />
    <Route path="/sign-in/*?" component={SignInPage} />
    <Route path="/sign-up/*?" component={SignUpPage} />
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}

function AppWithClerk() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`}
    localization={{ signIn:{ start:{ title:'Welcome back', subtitle:'Sign in to your ESPMUN España account' } }, signUp:{ start:{ title:'Create your account', subtitle:'Join the ESPMUN España network' } } }}
    routerPush={(to) => setLocation(stripBase(to))} routerReplace={(to) => setLocation(stripBase(to), { replace:true })}>
    <QueryClientProvider client={queryClient}><ClerkQueryClientCacheInvalidator /><TooltipProvider><Router /><Toaster /></TooltipProvider></QueryClientProvider>
  </ClerkProvider>;
}

function App() {
  return <WouterRouter base={basePath}><AppWithClerk /></WouterRouter>;
}

export default App;
